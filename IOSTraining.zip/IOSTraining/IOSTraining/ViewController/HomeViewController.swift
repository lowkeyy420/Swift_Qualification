//
//  HomeViewController.swift
//  IOSTraining
//
//  Created by prk on 19/04/23.
//

import UIKit
import CoreData

class HomeViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {

    var arrOfInitial = [String]()
    var arrOfName = [String]()
    
    var context : NSManagedObjectContext!
    
    @IBOutlet weak var initalTF: UITextField!
    @IBOutlet weak var nameTF: UITextField!
    @IBOutlet weak var insertBtn: UIButton!
    
    @IBAction func insertOnClicked(_ sender: UIButton) {
        let newInitial = initalTF.text!
        let newName = nameTF.text!
        
        let entity = NSEntityDescription.entity(forEntityName: "Assistant", in: context)
        
        let newAssistant = NSManagedObject(entity:entity!,insertInto:context)
        newAssistant.setValue(newInitial, forKey: "initial")
        newAssistant.setValue(newName, forKey: "name")
        
        do{
            try context.save()
            loadData()
        }
        catch {
            print("failed to insert assistant")
        }
        
    }
        
    @IBOutlet weak var assistantTV: UITableView!
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        return arrOfInitial.count
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 60
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        //function untuk tentuin data per cell dikasi apa
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell") as! AssistantTableViewCell
        
        cell.NewInitialTF.text = arrOfInitial[indexPath.row]
        cell.updateHandler = {
            self.updateData(cell: cell, indexPath: indexPath)
        }
        
        return cell
    }
    
    func loadData(){
        //load data berdasarkan array data yg ada
        arrOfInitial.removeAll()
        arrOfName.removeAll()
        
        //select all berdasarkan core data
        
        let request = NSFetchRequest<NSFetchRequestResult>(entityName: "Assistant")
        
        do{
            let results = try context.fetch(request) as! [NSManagedObject]
            
            for data in results {
                arrOfInitial.append(data.value(forKey: "initial") as! String)
                arrOfName.append(data.value(forKey: "name") as! String)
                
            }
            assistantTV.reloadData()
        }catch{
            print("failed to fetch assistant")
        }
        
        
    }
    
    func updateData(cell : UITableViewCell, indexPath : IndexPath)
    {
        
    }

    override func viewDidLoad() {
        super.viewDidLoad()
        let appDelegate = UIApplication.shared.delegate as! AppDelegate
        context = appDelegate.persistentContainer.viewContext
        assistantTV.delegate = self
        assistantTV.dataSource = self
        loadData()
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
