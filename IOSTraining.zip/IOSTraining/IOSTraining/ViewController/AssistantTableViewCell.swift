//
//  AssistantTableViewCell.swift
//  IOSTraining
//
//  Created by prk on 19/04/23.
//

import UIKit

class AssistantTableViewCell: UITableViewCell {

    
    
    @IBOutlet weak var NewInitialTF: UITextField!
    
    @IBOutlet weak var updateBtn: UIButton!
    
    
    var updateHandler = {
        
    };
    
    @IBAction func updateOnClicked(_ sender: UIButton) {
    }
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
