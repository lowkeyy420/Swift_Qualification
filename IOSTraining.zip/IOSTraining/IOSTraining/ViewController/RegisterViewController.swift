//
//  RegisterViewController.swift
//  IOSTraining
//
//  Created by prk on 19/04/23.
//

import UIKit
import CoreData

class RegisterViewController: UIViewController {
    
    @IBOutlet weak var usernameTF: UITextField!
    @IBOutlet weak var passwordTF: UITextField!
    @IBOutlet weak var confirmPasswordTF: UITextField!
    
    @IBOutlet weak var registerBtn: UIButton!
    @IBOutlet weak var loginRedirectBtn: UIButton!
    
    var context:NSManagedObjectContext!
    
    @IBAction func registerOnClicked(_ sender: UIButton) {
        //ambil value dari textfield
        //masukin db
        // let -> unmutable , var -> mutable (let kyk const)
        
        let username = usernameTF.text!
        let password = passwordTF.text!
        
        
        //bikin entity, bikin user, insert ke db
        let entity = NSEntityDescription.entity(forEntityName: "User", in: context)
        
        let newUser = NSManagedObject(entity:entity!,insertInto:context)
        newUser.setValue(username, forKey: "username")
        newUser.setValue(password, forKey: "password")
        
        
        do{
            try context.save()
            
            //ini buat bisa back
//            if let nextView = storyboard?.instantiateViewController(withIdentifier: "LoginViewController") {
//                navigationController?.pushViewController(nextView, animated: true)
//            }
            
            if let nextView = storyboard?.instantiateViewController(withIdentifier: "LoginViewController") {
                navigationController?.setViewControllers([nextView], animated: true)
            }
            
            
        }
        catch{
            print("insert failed")
        }
        
        
        
        
    }
    
    
    
    @IBAction func redirectLoginOnClicked(_ sender: UIButton) {
        if let nextView = storyboard?.instantiateViewController(withIdentifier: "LoginViewController") {
            navigationController?.setViewControllers([nextView], animated: true)
        }
        
        
    }
    
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        let appDelegate = UIApplication.shared.delegate as! AppDelegate
        context = appDelegate.persistentContainer.viewContext
        
        
        
    }
    
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
