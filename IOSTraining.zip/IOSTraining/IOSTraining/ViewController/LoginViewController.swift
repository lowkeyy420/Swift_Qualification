//
//  LoginViewController.swift
//  IOSTraining
//
//  Created by prk on 19/04/23.
//

import UIKit
import CoreData

class LoginViewController: UIViewController {

    @IBOutlet weak var usernameTF: UITextField!
    
    @IBOutlet weak var passwordTF: UITextField!
    
    @IBOutlet weak var loginBtn: UIButton!
    
    @IBOutlet weak var registerRedirectBtn: UIButton!
    
    var context:NSManagedObjectContext!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        let appDelegate = UIApplication.shared.delegate as! AppDelegate
        context = appDelegate.persistentContainer.viewContext
    }
    
    @IBAction func redirectRegisterOnClicked(_ sender: UIButton) {
        if let nextView = storyboard?.instantiateViewController(withIdentifier: "RegisterViewController") {
            navigationController?.setViewControllers([nextView], animated: true)
        }
    }
    
    @IBAction func loginOnClicked(_ sender: UIButton) {
        //ambil data dari text field
        
        let username = usernameTF.text!
        let password = passwordTF.text!
        
        //request ke coredata
        
        let request = NSFetchRequest<NSFetchRequestResult>(entityName: "User")
        request.predicate = NSPredicate(format: "username == %@ AND password == %@", username, password)
        
        //coba fetch
        do{
            let result = try context.fetch(request) as! [NSManagedObject]
            if result.count == 0{
                print("login failed")
            }
            else {
                print("sucessfully loggin")
                if let nextView = storyboard?.instantiateViewController(withIdentifier: "HomeViewController") {
                    navigationController?.setViewControllers([nextView], animated: true)
                }
            }
            
            
        } catch{
            print("request failed")
        }
        
    }
    
    /*
    // MARK: - Navigation
    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
